package motorph.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainDashboard extends JFrame {
    private String userRole;

    public MainDashboard(String userRole) {
        this.userRole = userRole;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("MotorPH Payroll System - Dashboard (" + userRole + ")");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 240, 240));

        createComponents();
        setupButtonListeners();
        setVisible(true);
    }

    private void createComponents() {
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(new Color(240, 240, 240));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Header
        JLabel header = new JLabel("MotorPH Payroll System");
        header.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        mainPanel.add(header, gbc);

        // Buttons
        if (userRole.equals("admin")) {
            JButton empMgmtBtn = createDashboardButton("Employee Management", new Color(70, 130, 180));
            gbc.gridy = 1;
            mainPanel.add(empMgmtBtn, gbc);
        }

        // Change this to use motorph.gui.MainMenu
        JButton mainMenuBtn = createDashboardButton("Main Menu", new Color(52, 152, 219));
        gbc.gridy = 2;
        mainPanel.add(mainMenuBtn, gbc);

        JButton payrollBtn = createDashboardButton("Payroll Processing", new Color(46, 204, 113));
        gbc.gridy = 3;
        mainPanel.add(payrollBtn, gbc);

        JButton reportsBtn = createDashboardButton("Reports", new Color(155, 89, 182));
        gbc.gridy = 4;
        mainPanel.add(reportsBtn, gbc);

        JButton logoutBtn = createDashboardButton("Logout", new Color(231, 76, 60));
        gbc.gridy = 5;
        mainPanel.add(logoutBtn, gbc);

        add(mainPanel);
    }

    private JButton createDashboardButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(250, 50));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(bgColor.darker());
            }
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    private void setupButtonListeners() {
        for (Component comp : getContentPane().getComponents()) {
            if (comp instanceof JPanel) {
                for (Component btn : ((JPanel)comp).getComponents()) {
                    if (btn instanceof JButton) {
                        JButton button = (JButton)btn;
                        button.addActionListener(e -> handleButtonClick(button.getText()));
                    }
                }
            }
        }
    }

    private void handleButtonClick(String buttonText) {
        switch (buttonText) {
            case "Employee Management":
                openEmployeeManagement();
                break;
            case "Main Menu":
                openMainMenu();
                break;
            case "Payroll Processing":
                showSimpleDialog("Payroll Processing", "This would process payroll");
                break;
            case "Reports":
                showSimpleDialog("Reports", "This would show reports");
                break;
            case "Logout":
                logout();
                break;
        }
    }

    private void openMainMenu() {
        SwingUtilities.invokeLater(() -> {
            // Use the MainMenu from motorph.gui package
            MainMenu mainMenu = new MainMenu(); // Remove userRole parameter
            mainMenu.setLocationRelativeTo(this);
            mainMenu.setVisible(true);
            this.dispose();
        });
    }

    private void openEmployeeManagement() {
        for (Window window : Window.getWindows()) {
            if (window instanceof EmployeeManagement) {
                window.dispose();
            }
        }

        SwingUtilities.invokeLater(() -> {
            EmployeeManagement empManagement = new EmployeeManagement();
            empManagement.setLocationRelativeTo(this);
            empManagement.setVisible(true);
            this.dispose();
        });
    }

    private void showSimpleDialog(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new LoginForm().setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainDashboard("admin"));
    }
}