package motorph.gui;

import motorph.employee.Employee;
import motorph.process.PayrollProcessor;
import motorph.process.PayrollProcessor.PayrollResult;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class PayrollFrame extends JFrame {
    private JComboBox<String> employeeBox;
    private JComboBox<String> monthBox;
    private JComboBox<Integer> yearBox;
    private JComboBox<String> periodBox;
    private JTextArea resultArea;

    public PayrollFrame() {
        setTitle("Payroll Calculator");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setupComponents();
        setupLayout();
    }

    private void setupComponents() {
        // Employee dropdown
        employeeBox = new JComboBox<>();
        employeeBox.addItem("John Doe (EMP001)");
        employeeBox.addItem("Jane Smith (EMP002)");

        // Month dropdown
        monthBox = new JComboBox<>(new String[]{"January","February","March","April","May","June",
                "July","August","September","October","November","December"});

        // Year dropdown
        yearBox = new JComboBox<>();
        int currentYear = java.time.Year.now().getValue();
        yearBox.addItem(currentYear);
        yearBox.addItem(currentYear + 1);

        // Pay period dropdown
        periodBox = new JComboBox<>(new String[]{"First Half (1-15)", "Second Half (16-end)"});

        // Results area
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Courier New", Font.PLAIN, 12));
    }

    private void setupLayout() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));

        // Input panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 5, 5));
        inputPanel.add(new JLabel("Employee:"));
        inputPanel.add(employeeBox);
        inputPanel.add(new JLabel("Month:"));
        inputPanel.add(monthBox);
        inputPanel.add(new JLabel("Year:"));
        inputPanel.add(yearBox);
        inputPanel.add(new JLabel("Pay Period:"));
        inputPanel.add(periodBox);

        // Button panel
        JButton calculateBtn = new JButton("Calculate Payroll");
        calculateBtn.addActionListener(this::calculatePayroll);

        JButton backBtn = new JButton("Back to Menu");
        backBtn.addActionListener(e -> {
            this.dispose();
            new MainMenu().setVisible(true);
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(calculateBtn);
        buttonPanel.add(backBtn);

        // Add everything to main panel
        mainPanel.add(inputPanel, BorderLayout.NORTH);
        mainPanel.add(new JScrollPane(resultArea), BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void calculatePayroll(ActionEvent e) {
        try {
            // Get selected values
            String employee = (String)employeeBox.getSelectedItem();
            String month = (String)monthBox.getSelectedItem();
            int year = (int)yearBox.getSelectedItem();
            String period = (String)periodBox.getSelectedItem();

            // Simple calculation (replace with your real calculation)
            double basicPay = 25000.0;
            double overtime = 1250.0;
            double deductions = 3500.0;
            double netPay = basicPay + overtime - deductions;

            // Display results
            showResults(employee, month, year, period, basicPay, overtime, deductions, netPay);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error calculating payroll: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showResults(String employee, String month, int year, String period,
                             double basicPay, double overtime, double deductions, double netPay) {
        String result = String.format(
                "=== PAYROLL RESULT ===\n\n" +
                        "Employee: %s\n" +
                        "Period: %s %d (%s)\n\n" +
                        "Basic Pay: ₱%,.2f\n" +
                        "Overtime: ₱%,.2f\n" +
                        "Deductions: ₱%,.2f\n" +
                        "------------------------\n" +
                        "NET PAY: ₱%,.2f",
                employee, month, year, period, basicPay, overtime, deductions, netPay
        );

        resultArea.setText(result);
    }
}