package motorph.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminLoginForm extends JFrame {
    public AdminLoginForm() {
        setTitle("Admin Login");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Admin Username:"));
        JTextField usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Admin Password:"));
        JPasswordField passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            if (usernameField.getText().equals("admin") &&
                    new String(passwordField.getPassword()).equals("admin123")) {
                dispose();
                new MainDashboard("admin");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid admin credentials");
            }
        });
        panel.add(loginButton);

        add(panel);
        setVisible(true);
    }
}