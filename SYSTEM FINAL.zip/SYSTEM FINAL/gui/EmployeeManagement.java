package motorph.gui;

import motorph.deductions.StatutoryDeductions;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class EmployeeManagement extends JFrame {
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private static final String CSV_FILE = "Employee Data.csv";
    private static final String ATTENDANCE_FILE = "AttendanceRecords.csv";
    private JButton backButton;

    public EmployeeManagement() {
        setupWindow();
        createTable();
        addButtons();
        loadEmployeeData();
        setVisible(true);
    }

    private void setupWindow() {
        setTitle("Employee Management");
        setSize(1500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private void createTable() {
        String[] columns = {
                "Employee #", "Last Name", "First Name", "Birthday", "Address",
                "Phone Number", "SSS #", "Philhealth #", "TIN #", "Pag-ibig #",
                "Status", "Position", "Immediate Supervisor", "Basic Salary",
                "Rice Subsidy", "Phone Allowance", "Clothing Allowance",
                "Gross Semi-monthly Rate", "Hourly Rate"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        employeeTable = new JTable(tableModel);
        employeeTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        int[] columnWidths = {80, 100, 100, 80, 250, 100, 100, 100, 100, 100,
                80, 150, 150, 100, 80, 80, 80, 120, 80};
        for (int i = 0; i < columnWidths.length; i++) {
            employeeTable.getColumnModel().getColumn(i).setPreferredWidth(columnWidths[i]);
        }

        add(new JScrollPane(employeeTable), BorderLayout.CENTER);
    }

    private void addButtons() {
        JPanel buttonPanel = new JPanel();

        JButton addEmployeeBtn = new JButton("Add Employee");
        addEmployeeBtn.addActionListener(e -> {
            NewEmployeeForm form = new NewEmployeeForm(this);
            form.setVisible(true);
        });

        JButton updateBtn = new JButton("Update Employee");
        updateBtn.addActionListener(e -> updateEmployee());

        JButton deleteBtn = new JButton("Delete Employee");
        deleteBtn.addActionListener(e -> deleteEmployee());

        JButton attendanceBtn = new JButton("Attendance Record");
        attendanceBtn.addActionListener(e -> viewAttendanceRecord());

        JButton employeeDataBtn = new JButton("Employee Data");
        employeeDataBtn.addActionListener(e -> viewEmployeeData());

        JButton payrollBtn = new JButton("Calculate Payroll");
        payrollBtn.addActionListener(e -> calculatePayroll());

        backButton = new JButton("Back to Main Menu");
        backButton.addActionListener(e -> {
            dispose();
            new MainDashboard("admin");
        });

        buttonPanel.add(addEmployeeBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(attendanceBtn);
        buttonPanel.add(employeeDataBtn);
        buttonPanel.add(payrollBtn);
        buttonPanel.add(backButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void updateEmployee() {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first");
            return;
        }
        // Add your update logic here
        JOptionPane.showMessageDialog(this, "Update employee functionality");
    }

    private void deleteEmployee() {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first");
            return;
        }
        // Add your delete logic here
        JOptionPane.showMessageDialog(this, "Delete employee functionality");
    }

    private void viewAttendanceRecord() {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first");
            return;
        }

        String employeeId = tableModel.getValueAt(row, 0).toString();
        String employeeName = tableModel.getValueAt(row, 2) + " " + tableModel.getValueAt(row, 1);

        try {
            File attendanceFile = new File(ATTENDANCE_FILE);
            if (!attendanceFile.exists()) {
                JOptionPane.showMessageDialog(this, "Attendance records file not found");
                return;
            }

            int totalDaysPresent = 0;
            int totalDaysLate = 0;
            int totalDaysAbsent = 0;
            int totalDaysHalfDay = 0;
            int totalDaysOvertime = 0;
            List<String> attendanceDetails = new ArrayList<>();
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            try (BufferedReader br = new BufferedReader(new FileReader(attendanceFile))) {
                String line;
                boolean firstLine = true;

                while ((line = br.readLine()) != null) {
                    if (firstLine) {
                        firstLine = false;
                        continue;
                    }

                    String[] record = line.split(",");
                    if (record.length >= 5 && record[0].equals(employeeId)) {
                        String date = record[1];
                        String status = record[4].toLowerCase();

                        switch (status) {
                            case "present":
                                totalDaysPresent++;
                                break;
                            case "late":
                                totalDaysLate++;
                                break;
                            case "absent":
                                totalDaysAbsent++;
                                break;
                            case "half-day":
                                totalDaysHalfDay++;
                                break;
                            case "overtime":
                                totalDaysOvertime++;
                                break;
                        }

                        attendanceDetails.add(String.format("%s - %s", date, status));
                    }
                }
            }

            // Calculate working days this month (for comparison)
            LocalDate today = LocalDate.now();
            LocalDate firstDayOfMonth = today.withDayOfMonth(1);
            long workingDaysThisMonth = ChronoUnit.DAYS.between(firstDayOfMonth, today) + 1; // +1 to include today

            String summary = String.format(
                    "<html><b>Attendance Summary for %s (ID: %s)</b><br><br>" +
                            "Total Days Present: %d<br>" +
                            "Total Days Late: %d<br>" +
                            "Total Days Absent: %d<br>" +
                            "Total Half Days: %d<br>" +
                            "Total Overtime Days: %d<br>" +
                            "<b>Total Working Days This Month: %d</b><br><br>" +
                            "<u>Attendance Details:</u><br>%s</html>",
                    employeeName, employeeId,
                    totalDaysPresent, totalDaysLate, totalDaysAbsent,
                    totalDaysHalfDay, totalDaysOvertime,
                    workingDaysThisMonth,
                    attendanceDetails.isEmpty() ? "No records found" : String.join("<br>", attendanceDetails)
            );

            JOptionPane.showMessageDialog(this,
                    summary,
                    "Attendance Record",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading attendance records: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewEmployeeData() {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first");
            return;
        }

        StringBuilder employeeData = new StringBuilder();
        employeeData.append("<html><b>Employee Details</b><br><br>");

        for (int col = 0; col < tableModel.getColumnCount(); col++) {
            String colName = tableModel.getColumnName(col);
            String value = tableModel.getValueAt(row, col).toString();
            employeeData.append(String.format("<b>%s:</b> %s<br>", colName, value));
        }

        employeeData.append("</html>");

        JOptionPane.showMessageDialog(this,
                employeeData.toString(),
                "Employee Data",
                JOptionPane.INFORMATION_MESSAGE);
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        loadEmployeeData();
    }

    private void loadEmployeeData() {
        try (BufferedReader br = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            boolean firstLine = true;

            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                List<String> values = parseCsvLine(line);

                if (values.size() >= 19) {
                    tableModel.addRow(values.toArray());
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading file: " + e.getMessage());
        }
    }

    private List<String> parseCsvLine(String line) {
        List<String> values = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder sb = new StringBuilder();

        for (char c : line.toCharArray()) {
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                values.add(sb.toString());
                sb = new StringBuilder();
            } else {
                sb.append(c);
            }
        }
        values.add(sb.toString());
        return values;
    }

    private void calculatePayroll() {
        int row = employeeTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee first");
            return;
        }

        try {
            String salaryStr = tableModel.getValueAt(row, 13).toString().replace(",", "");
            double monthlySalary = Double.parseDouble(salaryStr);

            StatutoryDeductions.DeductionResult mid =
                    StatutoryDeductions.calculateDeductions(monthlySalary/2, StatutoryDeductions.MID_MONTH, monthlySalary);

            StatutoryDeductions.DeductionResult end =
                    StatutoryDeductions.calculateDeductions(monthlySalary/2, StatutoryDeductions.END_MONTH, monthlySalary);

            showPayrollResults(tableModel.getValueAt(row, 2) + " " + tableModel.getValueAt(row, 1),
                    monthlySalary, mid, end);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error calculating payroll: " + e.getMessage());
        }
    }

    private void showPayrollResults(String name, double salary,
                                    StatutoryDeductions.DeductionResult mid,
                                    StatutoryDeductions.DeductionResult end) {
        double totalDeductions = mid.totalDeductions + end.totalDeductions;
        double netPay = salary - totalDeductions;

        String message = String.format(
                "<html><b>Payroll Details for %s</b><br><br>" +
                        "Monthly Salary: ₱%,.2f<br><br>" +
                        "<u>Mid-Month Deductions:</u><br>" +
                        "SSS: ₱%,.2f<br>PhilHealth: ₱%,.2f<br>Pag-IBIG: ₱%,.2f<br>" +
                        "Total: ₱%,.2f<br><br>" +
                        "<u>End-Month Deductions:</u><br>" +
                        "Withholding Tax: ₱%,.2f<br>Total: ₱%,.2f<br><br>" +
                        "<b>Total Deductions: ₱%,.2f</b><br>" +
                        "<b>Net Pay: ₱%,.2f</b></html>",
                name, salary,
                mid.sssDeduction, mid.philhealthDeduction, mid.pagibigDeduction, mid.totalDeductions,
                end.withholdingTax, end.totalDeductions,
                totalDeductions, netPay
        );

        JOptionPane.showMessageDialog(this, message, "Payroll Calculation", JOptionPane.INFORMATION_MESSAGE);
    }
}