package motorph.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class NewEmployeeForm extends JFrame {
    private final EmployeeManagement parent;

    public NewEmployeeForm(EmployeeManagement parent) {
        this.parent = parent;
        setupForm();
    }

    private void setupForm() {
        setTitle("Add New Employee");
        setSize(400, 300);
        setLocationRelativeTo(parent);

        JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Form fields
        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField positionField = new JTextField();
        JTextField salaryField = new JTextField();

        panel.add(new JLabel("First Name:"));
        panel.add(firstNameField);
        panel.add(new JLabel("Last Name:"));
        panel.add(lastNameField);
        panel.add(new JLabel("Position:"));
        panel.add(positionField);
        panel.add(new JLabel("Salary:"));
        panel.add(salaryField);

        // Buttons
        JButton saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> {
            // In a real implementation, you would save the new employee to CSV here
            JOptionPane.showMessageDialog(this, "Employee added successfully");
            parent.refreshTable(); // This refreshes the parent table
            dispose(); // Close the form
        });

        JButton cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(e -> dispose());

        panel.add(saveBtn);
        panel.add(cancelBtn);

        add(panel);
    }
}