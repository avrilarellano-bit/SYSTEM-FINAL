package motorph;

import motorph.employee.EmployeeDataReader;
import motorph.employee.Employee;
import motorph.gui.LoginForm;
import motorph.hours.AttendanceReader;
import motorph.input.PayrollInputManager;
import motorph.output.PayrollOutputManager;
import motorph.process.PayrollProcessor;

import javax.swing.*;
import java.time.LocalDate;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Main class for the MotorPH Payroll System
 * Entry point for the application
 */
public class Main {
    private static final Logger LOGGER = Logger.getLogger(Main.class.getName());
    private static final String EMPLOYEE_FILE = "resources/MotorPH Employee Data - Employee Details.csv";
    private static final String ATTENDANCE_FILE = "resources/MotorPH Employee Data - Attendance Record.csv";

    public static void main(String... args) {
        if (args.length > 0 && args[0].equals("--console")) {
            runConsoleMode();
        } else {
            runGuiMode();
        }
    }

    private static void runConsoleMode() {
        try (Scanner scanner = new Scanner(System.in)) {
            // Initialize components
            EmployeeDataReader employeeReader = new EmployeeDataReader(EMPLOYEE_FILE);
            AttendanceReader attendanceReader = new AttendanceReader(ATTENDANCE_FILE);
            PayrollProcessor processor = new PayrollProcessor(EMPLOYEE_FILE, ATTENDANCE_FILE);

            // Create managers
            PayrollInputManager inputManager = new PayrollInputManager(scanner, employeeReader);
            PayrollOutputManager outputManager = new PayrollOutputManager(scanner, attendanceReader, processor);

            // Start console interface
            runConsoleApplication(inputManager, outputManager, processor);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error in console mode", e);
            System.err.println("System error: " + e.getMessage());
        }
    }

    private static void runGuiMode() {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new LoginForm().setVisible(true);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,
                        "Failed to initialize application: " + e.getMessage(),
                        "Startup Error",
                        JOptionPane.ERROR_MESSAGE);
                LOGGER.log(Level.SEVERE, "GUI initialization failed", e);
            }
        });
    }

    private static void runConsoleApplication(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager,
            PayrollProcessor payrollProcessor) {

        while (true) {
            printMainMenu();
            String choice = inputManager.getMenuChoice();

            switch (choice) {
                case "1":
                    processPayroll(inputManager, outputManager, payrollProcessor);
                    break;
                case "2":
                    findEmployee(inputManager, outputManager, payrollProcessor);
                    break;
                case "3":
                    viewPayrollCalendar(inputManager, outputManager);
                    break;
                case "4":
                    System.out.println("Thank you for using MotorPH Payroll System. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("\n=== MOTORPH PAYROLL SYSTEM ===");
        System.out.println("1. Process Payroll");
        System.out.println("2. Find Employee");
        System.out.println("3. View Payroll Calendar");
        System.out.println("4. Exit");
        System.out.print("Enter your choice (1-4): ");
    }

    private static void processPayroll(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager,
            PayrollProcessor payrollProcessor) {

        int year = inputManager.getYear();
        int month = inputManager.getMonth();
        int payrollType = inputManager.getPayPeriodType();
        LocalDate[] cutoffDates = inputManager.getCutoffDateRange(year, month, payrollType);

        Employee employee = inputManager.findEmployee();
        if (employee == null) return;

        Map<String, Object> attendanceSummary = outputManager.displayPayrollSummary(
                employee, cutoffDates[0], cutoffDates[1], payrollType);
        if (attendanceSummary == null) return;

        if (inputManager.getConfirmation("\nAre these records accurate? (Y/N): ")) {
            processPayrollDetails(
                    inputManager,
                    outputManager,
                    payrollProcessor,
                    employee,
                    attendanceSummary,
                    cutoffDates[0],
                    cutoffDates[1],
                    year,
                    month,
                    payrollType
            );
        } else {
            System.out.println("Please double check the attendance file and try again.");
        }
    }

    private static void processPayrollDetails(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager,
            PayrollProcessor payrollProcessor,
            Employee employee,
            Map<String, Object> attendanceSummary,
            LocalDate startDate,
            LocalDate endDate,
            int year,
            int month,
            int payrollType) {

        double totalHours = (double) attendanceSummary.get("hours");
        double overtimeHours = (double) attendanceSummary.get("overtimeHours");
        double lateMinutes = (double) attendanceSummary.get("lateMinutes");
        double undertimeMinutes = (double) attendanceSummary.get("undertimeMinutes");
        boolean isLateAnyDay = (boolean) attendanceSummary.get("isLateAnyDay");
        boolean hasUnpaidAbsences = (boolean) attendanceSummary.get("hasUnpaidAbsences");

        payrollProcessor.processPayroll(
                employee, totalHours, overtimeHours, lateMinutes, undertimeMinutes,
                isLateAnyDay, payrollType, startDate, endDate, year, month, hasUnpaidAbsences);

        outputManager.displaySalaryDetails(employee);

        if (inputManager.getConfirmation("\nConfirm payroll for processing (Y/N): ")) {
            System.out.println("\nPayroll confirmed and processed.");
            System.out.println("Payment will be issued according to the company schedule.");
        } else {
            System.out.println("\nPayroll processing canceled.");
        }
    }

    private static void findEmployee(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager,
            PayrollProcessor payrollProcessor) {

        Employee employee = inputManager.findEmployee();
        if (employee == null) return;

        outputManager.displayEmployeeDetails(employee);
        String choice = inputManager.getMenuChoice();

        switch (choice) {
            case "1":
                checkEmployeeAttendance(inputManager, outputManager, employee);
                break;
            case "2":
                processPayroll(inputManager, outputManager, payrollProcessor);
                break;
            case "3":
                break;
            default:
                System.out.println("Invalid option. Returning to main menu.");
        }
    }

    private static void checkEmployeeAttendance(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager,
            Employee employee) {

        outputManager.displayAttendanceOptions(employee);
        String viewType = inputManager.getMenuChoice();
        LocalDate[] dateRange = inputManager.getDateRange();

        if (dateRange != null) {
            if (viewType.equals("1")) {
                outputManager.displayDailyAttendance(employee, dateRange[0], dateRange[1]);
            } else {
                outputManager.displayWeeklyAttendance(employee, dateRange[0], dateRange[1]);
            }
        }
    }

    private static void viewPayrollCalendar(
            PayrollInputManager inputManager,
            PayrollOutputManager outputManager) {

        int year = inputManager.getYear();
        int month = inputManager.getMonth();
        outputManager.displayPayrollCalendar(year, month);
        inputManager.waitForEnter();
    }

    /**
     * Run the main payroll system (called from GUI MainMenu)
     */
    public static void runPayrollSystem() {
        try (Scanner scanner = new Scanner(System.in)) {
            EmployeeDataReader employeeReader = new EmployeeDataReader(EMPLOYEE_FILE);
            AttendanceReader attendanceReader = new AttendanceReader(ATTENDANCE_FILE);
            PayrollProcessor processor = new PayrollProcessor(EMPLOYEE_FILE, ATTENDANCE_FILE);

            PayrollOutputManager outputManager = new PayrollOutputManager(scanner, attendanceReader, processor);
            PayrollInputManager inputManager = new PayrollInputManager(scanner, employeeReader);

            runConsoleApplication(inputManager, outputManager, processor);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error in payroll system", e);
        }
    }
}