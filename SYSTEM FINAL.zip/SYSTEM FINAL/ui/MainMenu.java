package motorph.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("MotorPH Payroll System - Main Menu");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(240, 240, 240));

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Payroll System Button - Now opens GUI version
        JButton payrollBtn = new JButton("Payroll System");
        payrollBtn.addActionListener(e -> {
            new PayrollFrame().setVisible(true);
            dispose();
        });

        // ... rest of your MainMenu code remains the same ...
        JButton employeeBtn = new JButton("Employee Management");
        employeeBtn.addActionListener(e -> {
            new EmployeeManagement().setVisible(true);
            dispose();
        });

        JButton reportsBtn = new JButton("Reports");
        reportsBtn.addActionListener(e -> showMessage("Reports are being generated!"));

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.addActionListener(e -> logout());

        JButton backBtn = new JButton("Back to Dashboard");
        backBtn.addActionListener(e -> backToDashboard());

        panel.add(payrollBtn);
        panel.add(employeeBtn);
        panel.add(reportsBtn);
        panel.add(logoutBtn);
        panel.add(backBtn);

        add(panel);
    }

    // ... rest of your helper methods remain the same ...
    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message);
    }

    private void logout() {
        dispose();
        new LoginForm().setVisible(true);
    }

    private void backToDashboard() {
        dispose();
        new MainDashboard("user").setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainMenu().setVisible(true));
    }
}